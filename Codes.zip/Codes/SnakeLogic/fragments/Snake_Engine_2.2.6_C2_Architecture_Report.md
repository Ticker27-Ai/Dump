# Snake Engine 2.2.6 — Static Logic / C2-Oriented Architecture Report

## Scope

This report analyzes the uploaded evidence set:

- `Snake Engine_2.2.6.apk`
- `classes.dex`
- `libengine.so`
- `com.snake.zip` (application-data-style dump)

The goal is to reconstruct the observable control/data flow, with special focus on network/control-plane ("C2-like") behavior, Android-side integration, IPC/process boundaries, and JNI/native handoff.

### Evidence discipline

This report distinguishes:

- **CONFIRMED**: directly observed in the supplied APK/DEX/native/data files.
- **INFERRED**: a semantic interpretation supported by multiple artifacts.
- **NOT ESTABLISHED**: cannot be proven from the supplied artifacts.

The report does not treat generic Firebase/Google infrastructure as malicious C2 merely because it uses network traffic.

---

# 1. Executive Finding

## 1.1 Main architecture

The application is a Flutter Android application with a custom Android bridge layer and native library:

```text
Android component layer
    |
    +-- com.Entry
    +-- com.snake.App
    +-- com.snake.helper.*
              |
              +-- Native
              +-- InternalWebBrowser
              +-- ProxyActivity / ProxyService / ProxyJobService
              +-- ProxyContentProvider / SystemCallProvider
              +-- DaemonService
              +-- ProxyVpnService
              |
              +-- JNI
                    |
                    +-- libengine.so

Flutter AOT
    |
    +-- libapp.so
```

`libapp.so` is where the application-specific Flutter/Dart strings and HTTP-related strings are embedded. The observed custom endpoints are present in `libapp.so`, not in `libengine.so`.

## 1.2 Network/control-plane conclusion

**CONFIRMED custom application endpoints in `libapp.so`:**

- `https://www.snakeengine.com/topup/`
- `https://rest.snakeseller.com/api/request/`

Associated application strings include:

- `Access Token`
- `Your Seller Id :`
- `Recent Orders`
- `Order Details`
- `All Orders`
- `Login only for sellers`
- `This device can have access to seller login...`
- `Order ID`

This establishes a real application control/data plane involving seller authentication, order data, and request/top-up functionality.

**NOT ESTABLISHED:** a classic malware-style C2 beacon/polling protocol. The supplied static artifacts do not expose a clear repeating interval, command table, task queue, or explicit "beacon -> receive command -> execute command" protocol.

The strongest "control-channel-like" components are:

1. `ProxyContentProvider.call(...)`
2. `SystemCallProvider.call(...)`
3. `ProxyService` / `ProxyJobService`
4. `DaemonService`
5. FCM push infrastructure

These can deliver or dispatch asynchronous control, but the evidence is insufficient to label them malicious C2 without further runtime tracing.

---

# 2. APK Integration

## 2.1 Native libraries

The APK contains:

```text
lib/arm64-v8a/libapp.so
lib/arm64-v8a/libengine.so
lib/arm64-v8a/libflutter.so
```

Architecture: AArch64 / arm64-v8a.

`libapp.so` is a Dart AOT snapshot-style library:

- `.rodata` contains application strings.
- `.text` contains compiled Dart AOT code.
- dynamic symbol table exposes Dart snapshot objects rather than conventional application-level function symbols.

This means ordinary JADX output is not sufficient to reconstruct the Dart business functions; native/AOT analysis or runtime tracing is needed for exact function-level reconstruction.

## 2.2 Custom Android package surface

Observed custom classes include:

```text
com.Entry
com.snake.App
com.snake.helper.Native
com.snake.helper.MethodUtils
com.snake.helper.InternalWebBrowser
com.snake.helper.DaemonService
com.snake.helper.ProxyActivity
com.snake.helper.ProxyBroadcastReceiver
com.snake.helper.ProxyContentProvider
com.snake.helper.ProxyJobService
com.snake.helper.ProxyPendingActivity
com.snake.helper.ProxyService
com.snake.helper.ProxyVpnService
com.snake.helper.SystemCallProvider
com.snake.helper.TransparentProxyActivity
```

---

# 3. classes.dex Mapping

## 3.1 `com.Entry`

Observed lifecycle/callback surface:

```text
onCreate()
onResume()
onStop()
onActivityResult(...)
onRequestPermissionsResult(...)
```

Semantic role:

**Flutter/Android application entrypoint and callback dispatcher.**

Inputs:

- launch Intent
- activity results
- runtime permission results

Potential sinks:

- native bridge
- browser/auth result handling
- Flutter UI/runtime

The exact business branches inside obfuscated helpers such as `Y`, `Z`, `f0`, `a0`, `b0`, `c0`, `g0`, `h0`, `i0`, `j0` require bytecode-level decompilation to prove individually.

---

# 4. Native Bridge

## 4.1 `com.snake.helper.Native`

Observed native methods:

```text
ac(Object,Object)
aior(String,String)
awl(String)
chl(byte[]) -> boolean
djp(int) -> byte[]
eio()
i(int)
ic(Context)
ilil(int) -> String
pjowqpxe(Object,Object,Object)
update(Object, Method)
```

Observed Java-side helpers include:

```text
a(Activity,String,int,long,boolean)
b(Activity,String,int,long,boolean)
gcuid(int) -> int
getApplicationInfo(Context,String) -> ApplicationInfo
il(File) -> File
il(String) -> String
logIn(String,long)
logIn(String,long,boolean)
```

Semantic grouping:

| Function group | Interpretation |
|---|---|
| `logIn*` | login/session bridge |
| `getApplicationInfo` | package/app information lookup |
| `il(String/File)` | string/path transformation or normalization |
| `chl(byte[])` | byte-buffer decision/validation; exact operation unproven |
| `djp(int)` | native byte-buffer retrieval/derivation; exact operation unproven |
| `aior/awl/...` | opaque native dispatch |
| `update(Object,Method)` | reflection/native bridge support |

**Important:** names such as `LoginBridge`, `TokenDecode`, etc. are semantic labels only; they are not recovered original names.

---

# 5. Native `libengine.so`

## 5.1 Observed imported capabilities

The native library imports or references:

```text
mmap
mprotect
munmap
sysconf
rand
malloc
memcpy
memset
getaddrinfo
freeaddrinfo
dladdr
dlsym
readlink
prctl
getauxval
sigaction
signal
raise
process_vm_readv
pthread_*
ioctl
```

This is a broader runtime/anti-analysis capability set than a minimal JNI wrapper.

## 5.2 `JNI_OnLoad`

Observed behavior from the disassembly previously analyzed:

```text
JNI_OnLoad
  -> sysconf(_SC_PAGESIZE)
  -> mmap(..., PROT_READ|WRITE|EXEC, ...)
  -> multiple allocations/initialization passes
  -> rand()
  -> writes into generated region
  -> internal cache/flush helper
```

Semantic interpretation:

**Runtime memory/bootstrap layer.**

This is consistent with generated/unpacked runtime data or other executable-memory preparation.

It is NOT, by itself, evidence of C2.

## 5.3 Native helper groups

### `ResolveIPv4Address`
Observed API path:

```text
getaddrinfo()
    -> sockaddr/IPv4 extraction
    -> freeaddrinfo()
```

Likely role: hostname resolution utility.

### `EncodeBytesToHex`
Observed pattern:

```text
byte[]
 -> split high/low nibble
 -> hexadecimal ASCII
 -> allocated string
```

Likely role: serialization / identifier formatting / logging / signature support.

### `DuplicateStringSafe`

Likely role: allocated string duplication.

### `DetectRuntimeEnvironment`

Observed inputs include:

```text
ro.build.version.sdk
ro.arch
getauxval()
```

Likely role:

```text
device/runtime capability gating
```

Possible anti-analysis relevance exists, but no exact anti-debug verdict is made from this alone.

---

# 6. Application Network Plane

## 6.1 Custom endpoints

### Endpoint A

```text
https://www.snakeengine.com/topup/
```

Observed nearby application concepts:

```text
Access Token
Your Access Token
Seller
Topup
```

Semantic role:

**seller/top-up web destination**

The artifact does not prove whether this is a pure WebView page, server API, or redirect target at every call site.

### Endpoint B

```text
https://rest.snakeseller.com/api/request/
```

Observed nearby concepts:

```text
Order
Order ID
Recent Orders
Order Details
All Orders
Seller
Access Token
```

Semantic role:

**custom REST request endpoint for application data/operations.**

This is the strongest candidate for the application's custom control/data API.

---

# 7. Token / Identity Plane

Observed application strings:

```text
Access Token
Your Access Token
Your Seller Id :
Successfully copied your seller ID
Tap to logout from your seller account
Login only for sellers
```

This supports the following model:

```text
Seller identity
    |
    +-- Seller ID
    |
    +-- Access Token
            |
            +-- authenticated request
                    |
                    +-- order/request data
```

The static evidence does not reveal the exact header name or token transport mechanism for the custom REST endpoint.

Do not assume `Authorization: Bearer` unless runtime request code confirms it.

---

# 8. Orders / Request Logic

Observed user-visible concepts:

```text
Recent Orders
Order Details
All Orders
Order ID
```

Most conservative reconstruction:

```text
Seller session
   |
   v
authenticated backend request
   |
   +--> recent orders
   |
   +--> all orders
   |
   +--> selected order details
   |
   +--> request/top-up operation
```

The exact endpoint path for each order operation is not recoverable from the string evidence alone.

The only exact custom REST path observed is:

```text
https://rest.snakeseller.com/api/request/
```

---

# 9. Web Authentication / Browser Plane

Observed URL/string family includes:

```text
https://accounts.google.com/o/oauth2/v2/auth
https://www.google.com
https://www.facebook.com/
https://t.me/
https://wa.me/
https://discord.com/invite/
```

`InternalWebBrowser` contains:

```text
WebView
ProgressBar
URL validation helpers
navigation/lifecycle callbacks
```

Therefore:

```text
Android Activity
   |
   v
InternalWebBrowser
   |
   v
WebView
   |
   +--> external/auth/social destination
```

This is separate from the custom REST endpoint.

---

# 10. IPC / Multi-Process Architecture

## 10.1 Proxy class naming

DEX contains generated proxy variants:

```text
ProxyActivity$P0
ProxyActivity$P1
ProxyActivity$P2
ProxyActivity$P3

ProxyService$P0
ProxyService$P1
ProxyService$P2
ProxyService$P3

ProxyJobService$P0
ProxyJobService$P1
ProxyJobService$P2
ProxyJobService$P3

ProxyPendingActivity$P0
ProxyPendingActivity$P1
ProxyPendingActivity$P2
ProxyPendingActivity$P3

TransparentProxyActivity$P0
...
$P3

ProxyContentProvider$P0
...
$P3
```

This is strong evidence for a 4-way proxy family (`P0`..`P3`).

## 10.2 Provider command surface

`ProxyContentProvider` exposes:

```text
call(String, String, Bundle)
query(...)
insert(...)
update(...)
delete(...)
getType(...)
```

`SystemCallProvider` exposes the same broad provider surface and additionally includes:

```text
call(...)
a() -> boolean
b(Bundle)
```

Semantic interpretation:

**ContentProvider-based IPC/control dispatch.**

This is a key architecture bottleneck because command identity is encoded at runtime through strings/Bundles rather than obvious statically named methods.

---

# 11. Background Execution Plane

## 11.1 DaemonService

Observed methods:

```text
onStartCommand(...)
onTaskRemoved(...)
onDestroy()
onBind(...)
```

The presence of `onTaskRemoved()` is significant.

Most conservative interpretation:

```text
task removed
   |
   v
daemon/background state handling
   |
   v
possible restart/reschedule
```

Exact restart policy is not established without method bytecode.

## 11.2 JobService / Foreground Service

Observed:

```text
ProxyJobService
ProxyService
ProxyVpnService
DaemonService
```

Combined with manifest permissions for foreground-service and wake-lock operation, the Android layer supports long-running/background workflows.

---

# 12. FCM / Firebase Control Channel

The application data contains Firebase-related state:

```text
Firebase Messaging auto_init = true
Firebase installation/auth state
Firebase app id
Google/Firebase transport databases
```

The dump also contains a Firebase registration token.

For safety and reproducibility, this report intentionally REDACTS live token values.

### Important interpretation

FCM is a genuine remote-message delivery channel, but:

```text
FCM message delivery
!=
malicious C2
```

Static evidence here proves the app has a push-messaging path, not what commands may be carried inside a push.

A runtime trace would be needed to establish:

```text
FCM message
 -> callback
 -> command parser
 -> local action
```

or to disprove such behavior.

---

# 13. C2-Oriented Logic Reconstruction

## 13.1 Best-supported control/data-flow model

```text
                    +----------------------+
                    |      Seller/User     |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | com.Entry / Flutter  |
                    +----------+-----------+
                               |
                +--------------+--------------+
                |                             |
                v                             v
       +----------------+            +-------------------+
       | Native Bridge  |            | InternalWebBrowser|
       +-------+--------+            +---------+---------+
               |                               |
               v                               v
       +----------------+              Web / OAuth / Topup
       | libengine.so  |
       +----------------+

Flutter/Dart application plane
        |
        +--> seller authentication
        |
        +--> access token
        |
        +--> order data
        |
        +--> REST request
                |
                v
      https://rest.snakeseller.com/api/request/

Top-up/web plane
        |
        v
https://www.snakeengine.com/topup/

Async/background plane
        |
        +--> ProxyService
        +--> ProxyJobService
        +--> DaemonService
        +--> ProxyContentProvider
        +--> SystemCallProvider
        +--> FCM
```

---

# 14. What can be called "C2-like"

## High confidence

### Custom remote control/data endpoint

```text
rest.snakeseller.com/api/request/
```

Because it is:

- custom domain
- custom REST path
- surrounded by order/seller/access-token application semantics

### Remote web/top-up control plane

```text
snakeengine.com/topup/
```

Because it is clearly bound to the application's seller/top-up workflow.

## Medium confidence

### Push-driven asynchronous control

```text
FCM
   |
   v
FirebaseMessaging
```

The channel exists. The application-specific message semantics are not recovered.

### Cross-process command routing

```text
ProxyContentProvider.call(...)
SystemCallProvider.call(...)
```

These are explicit command-like dispatch surfaces, but the supplied static evidence does not identify the complete command vocabulary.

## Not established

The following were NOT proven:

- malware-style periodic beacon
- hard-coded C2 IP
- encrypted C2 protocol
- task polling interval
- command execution shell
- remote arbitrary-code execution
- data exfiltration protocol
- covert DNS C2

No such conclusion should be made from the current static set.

---

# 15. Integration Bottlenecks / Weak Points

## 15.1 Single native bridge choke point

```text
com.snake.helper.Native
```

A large amount of cross-layer behavior funnels through this class.

Impact:

- difficult to trace
- native failures propagate upward
- opaque return types make static reasoning harder

## 15.2 Provider-based dispatch

```text
ProxyContentProvider.call()
SystemCallProvider.call()
```

These are high-value analysis points because a generic:

```text
String method
String arg
Bundle extras
```

interface can hide many distinct operations behind one entrypoint.

## 15.3 AOT Flutter code

Business logic embedded in:

```text
libapp.so
```

has poor symbolic visibility.

This is the largest static-analysis bottleneck for exact request construction.

## 15.4 Runtime/native initialization

`libengine.so` uses:

```text
mmap
mprotect
rand
dlsym
dladdr
readlink
prctl
getauxval
signal/sigaction
```

This complicates purely static tracing and suggests runtime-dependent behavior.

## 15.5 Process fan-out

The proxy families P0-P3 create several parallel routing surfaces.

A wrong mapping between:

```text
component
process
proxy ID
command
```

can lead to incorrect assumptions about ownership/state.

---

# 16. Data Classification

| Data | Source | Processing | Sink |
|---|---|---|---|
| Seller ID | app/user session | copied/displayed | UI/local state/backend requests |
| Access Token | login/session | stored/forwarded | custom request path |
| Order ID | backend/UI | request parameter | REST backend |
| Order data | REST API | parsed/displayed | Flutter/UI |
| Top-up request | user/order flow | web navigation/request | `snakeengine.com` |
| Push token | Firebase | registration | Firebase infrastructure |
| Device/runtime properties | native layer | environment checks | global native state |

---

# 17. Evidence Contamination Warning

The uploaded `com.snake.zip` is NOT a clean APK source tree.

It contains an unexpected nested path:

```text
com.snake/root/data/user/0/com.miniclip.eightballpool/
```

and artifacts clearly belonging to another package, including:

```text
com.miniclip.eightballpool
```

and its advertising/analytics/game libraries.

There is also:

```text
com.snake/root/proc/0/cmdline
```

whose content identifies:

```text
com.miniclip.eightballpool
```

Therefore the data dump appears to be a mixed/contaminated collection rather than a pristine `com.snake` process dump.

### Consequence

Artifacts under:

```text
com.snake/root/data/user/0/com.miniclip.eightballpool/
```

must NOT be attributed to Snake Engine.

The main `com.snake/` app-data area is still useful, but provenance should be treated carefully.

---

# 18. Sensitive Artifact Warning

The dump contains live-looking Firebase installation/registration credentials/tokens.

The report deliberately redacts them.

These values should be treated as credentials/session material and not reused.

---

# 19. Final Architecture Model

```text
                           INTERNET
                              |
        +---------------------+---------------------+
        |                     |                     |
        v                     v                     v
  Custom REST API        Top-up/Web            Firebase/FCM
  snakeseller.com        snakeengine.com        Messaging
        |                     |                     |
        +----------+----------+----------+----------+
                   |
                   v
          Flutter/Dart AOT (libapp.so)
                   |
             Android Bridge
                   |
        +----------+-----------+
        |                      |
        v                      v
 Native helper             Proxy/IPC layer
  Native.java          P0 / P1 / P2 / P3
        |                      |
        v                      +--> Activity
   libengine.so               +--> Service
        |                     +--> JobService
        |                     +--> ContentProvider
        |                     +--> SystemCallProvider
        |
        +--> environment/runtime initialization

Background execution:
DaemonService / ProxyService / ProxyJobService / ProxyVpnService
```

---

# 20. Overall Assessment

### Confirmed

- Flutter AOT application.
- Custom Android helper/proxy architecture.
- JNI/native bridge.
- Four proxy families P0-P3.
- Background/daemon service surface.
- FCM/Firebase integration.
- Seller authentication/token concepts.
- Order management concepts.
- Two custom application domains/endpoints:
  - `www.snakeengine.com`
  - `rest.snakeseller.com`

### Strongly inferred

- `rest.snakeseller.com/api/request/` is the principal custom application API/control endpoint.
- `snakeengine.com/topup/` is a web/top-up workflow.
- Proxy providers/services form an IPC/command-routing layer.
- Native runtime initialization is distinct from business networking.

### Not established

- A malicious C2 protocol.
- Exact request headers/body schemas.
- Exact authentication header format.
- Exact polling/beacon mechanism.
- Exact push-command schema.
- Arbitrary command execution.

The current artifact set is sufficient to map the **architecture and control-plane boundaries**, but not sufficient to claim a fully recovered C2 protocol.

---

# Appendix A — Recommended next evidence for exact C2 reconstruction

The highest-value evidence, in order:

1. Runtime HTTP capture from a controlled lab device/emulator.
2. `logcat` during login/order/top-up activity.
3. Frida/ptrace-level call traces around:
   - `Native.logIn`
   - `Native` native methods
   - `ProxyContentProvider.call`
   - `SystemCallProvider.call`
   - Firebase message callbacks
4. Decompiled `com.snake.helper.*` method bodies.
5. A native disassembly database (Ghidra/IDA) with `libengine.so`.
6. Dart AOT symbol/reconstruction output for `libapp.so`.

These would allow the currently unresolved links to be converted from inference into confirmed data-flow edges.

---

## Artifact fingerprints

SHA-256:

```text
Snake Engine_2.2.6.apk
f847608605ea1da9a7452f2072ee59e4dc26a900ca2aad0315c967c9c896d561

classes.dex
e2b1fb586a9a85b4f094340458ea350eb1faafd602b8a4a287d4b3b97297af11

libengine.so
f5d751e6bde8f0595eda9836338e845b029a41d2362743a2a4619ba99f41e3be

com.snake.zip
743c4d8709487fb4fa9d24e6ca3a75b0d9cd2316b632a0fceae0c1c6cf922315
```
