# SNAKE Engine — เส้นทางการเชื่อมโยงการโหลดเกม (Chain of Evidence)
วันที่ตรวจสอบ: 2026-09-12 · Engine: Snake Engine v2.2.6 (`com.snake`) · เกมต้นแบบ: `com.miniclip.eightballpool`

---

## 0. 🆕 เส้นทาง Install & Launch ฉบับสมบูรณ์ (App เปิด → เกมรัน)

### ขั้น A — เปิดแอพ (Main process `com.snake`)
```
com.snake.App.attachBaseContext(ctx)
  ├─ static { System.loadLibrary("engine") }  ← libengine.so JNI_OnLoad (register natives, obfuscated)
  ├─ zh.a(app)                                  ← n1.c().d(app) + p60.a().b()  (framework init)
  └─ yu0.h().f(ctx, App.a())
       ├─ อ่าน processName (yu0.s())
       │    ├─ Main            → เตรียม UI
       │    ├─ ":engine" suffix (bn0.a=0x7f100041 "engine_service_name") → Server role
       │    └─ ChildAppClient  → Native.ic(ctx) ← (native init)
com.snake.App.onCreate → yu0.h().g()
  └─ Main: at0.d() → ลงทะเบียน fake services 8 ตัว
       {activity_manager: ev0.h(), package_manager: x6.w2(), job/storage/user/account/location/notification_manager}
       → ทุก service ไป binder ที่ yu0.t("package_manager") ฯลฯ = IBinder จาก server :engine
Launcher = com.Entry (Flutter, io.flutter.embedding) → UI Dart (libapp.so)
```

### ขั้น B — INSTALL (เกมถูกลงทะเบียนเข้าระบบเสมือน)
```
Flutter UI → MethodChannel → Entry → yu0 → qv0.g() [package_manager client proxy]
qv0.s(packageName, j50 flags, userId)      ← คำสั่ง install
  └─ binder m00.U0 (transact → server :engine)
       └─ x6.U0 → x6.C2(pkg, flags, uid):   [SERVER SIDE — install จริง]
            ├─ flag 8 → คัดลอกจาก uri → cache/uuid.apk (lr.c)
            ├─ yu0.r().getPackageArchiveInfo() ← อ่าน APK จริง (เช็ค valid)
            ├─ ตรวจ 32/64-bit (a.d(file))
            ├─ F2(path) = PackageParser แตก components ครบ (activities/services/providers)
            ├─ pt0.b(pkg, parsed, flags) → y6 = BPackage (virtual package obj)
            ├─ w6.h().w(y6, uid) → 3 ขั้นตอน install:
            │    ├─ bi.a  — เคลียร์/สร้าง data dirs (lv0.b/c)
            │    ├─ eh.a  — คัดลอก APK → virtual install dir (oe0.a แตก .so ตาม ABI)
            │    └─ ci.a  — สร้าง user dirs (lv0.k/i/g/j/h/l)
            ├─ b2.j(true, uid); b2.i()  → persist **package.conf** (Java serialize ของ y6
            │     ไปที่ lv0.p(pkg) = data/app/<pkg>/package.conf ← ไฟล์ 173,904B ที่เรามี!)
            ├─ m.r(b2.m); m.b(b2.m)     → ลงทะเบียน component resolvers
            └─ D2(pkg, uid) → bh0 listeners → broadcast กลับ UI
Result: k50 {m=success, n=packageName} → กลับ Flutter
```
> **หลักฐาน:** package.conf ใน comsnake-live = ผลลัพธ์ของ x6.C2 (Java serialize ของ y6/BPackage) — versionCode 3965×149, targetSdk 35, path base64 install dir — ยืนยันสถาปัตยกรรมแบบ ninja ที่ใช้ `BPackage` เหมือนกัน

### ขั้น C — LAUNCH (channel "G" — กดปุ่มเริ่มเกม)
```
Flutter UI (libapp.so Dart) → MethodChannel("G") → com.Entry.C(id0, dVar) case "G"
  ├─ yu0.h().A(pkg, uid)   → เช็ค installed? (x6)
  ├─ yu0.h().x(pkg, uid)   → getPackageInfo → k50
  └─ yu0.h().C(pkg, uid):  ← จุดเปิดเกมจริง
       ├─ qv0.l(pkg, uid)  สร้าง Intent:
       │    ACTION_MAIN + CATEGORY_INFO (fallback LAUNCHER)
       │    → x6.W0 resolve → EightBallPoolActivity
       │    → intent.setClassName("com.miniclip.eightballpool", "...EightBallPoolActivity")
       │       flags=FLAG_ACTIVITY_NEW_TASK(0x10000000)
       └─ yu0.F(intent, uid) → dv0.C(intent, uid)
            └─ binder g00.n0 (transact code=3 → :engine server)
```

### ขั้น D — Server เลือก stub + ยิงจริง (ev0)
```
ev0.n0(intent, uid)                    [SERVER :engine]
  ├─ k(uid) → p41 (per-user process table {b1 stubs, r1 pending})
  ├─ k.b.v(uid, intent, ...)           ← stub scheduler
  │    └─ เลือก stub ว่าง → kl0:
  │         kl0.i(i)   = "com.snake.helper.ProxyService$P%d"
  │         kl0.b/kl0.? = "com.snake.helper.ProxyActivity$P%d" / "TransparentProxyActivity$P%d"
  ├─ b1.d(...) สร้าง stub Intent:
  │    component = ProxyActivity$P0..P3 (ตาม process suffix :p0..:p3)
  │    action = UUID.randomUUID()
  │    rl0.b(stubIntent, realIntent, serviceInfo, ...)  ← แพ็ค real intent เป็น extra
  └─ yu0.m().startActivity(stubIntent)  ← ★ REAL system call (AMS ของ Android)
       Android จึงเปิด process ใหม่ของ com.snake เอง ชื่อ :p0 พร้อม ProxyActivity$P0
```

### ขั้น E — เกมถูกดึงขึ้นมารันใน :p0 (ChildAppClient)
```
:p0 attachBaseContext → yu0.f() = ChildAppClient → Native.ic(ctx) ← native hooks พร้อม
ProxyActivity$P0.onCreate (stub)
  └─ jv0 (BActivityThread เทียบ ninja) — bindApplication เกม:
       ├─ ดึง pending real intent จาก b1/yu0.u()
       ├─ qv0/x6 โหลด y6 (BPackage) จาก package.conf ของ com.miniclip.eightballpool
       ├─ z2(appInfo) = ClassLoader ชี้ base.apk เกม (ผ่าน redirect)
       ├─ a3() setup context, t1.b.e(...) inject ApplicationInfo/ClassLoader
       ├─ m90.i.b(instrumentation, ...) → newApplication("EightBallPoolApplication") ★
       │    (Instrumentation.newApplication = จุดเดียวกับที่ kaorios hook ฝั่ง user เจอ!)
       ├─ zh.a(gameApp) → AppInstrumentation delegate
       ├─ r3.g().callActivityOnCreate → EightBallPoolActivity ★
       │    → hidden dex (InMemoryDexClassLoader) + MethodUtils → Native.update(obj, method)
       │      → libengine.so inline-hooks เกม (vdex verifier deps: Executable/AccessibleObject/PackageItemInfo)
       └─ เกมรัน (EightBallPoolActivity onResume)
```

### ตาราง class map (SNAKE ↔ ninja reference)
| บทบาท | SNAKE (obf) | ninja (ชื่อจริง) |
|---|---|---|
| ActivityThread เสมือน | jv0 | BActivityThread |
| Instrumentation delegate | zh | AppInstrumentation |
| AMS server | ev0 | IBActivityManagerService |
| PMS server/installer | x6 (+pt0/w6/bi/eh/ci) | IBPackageManagerService |
| AMS/PMS client | dv0/qv0 (extends kv0) | — |
| Stub chooser | kl0/b1/p41 | — |
| Native bridge | com.snake.helper.Native | com.ninja... Native |

---

## 1. สถาปัตยกรรม 4 Process

```
com.snake (Main, Flutter UI)
   │  System.loadLibrary("engine")
   │  yu0.f() → role=Main → Native.ic(ctx)
   │  yu0.g() → at0.d() → Binder connect ไป server
   ▼
:engine (Server — DaemonService + SystemCallProvider)
   │  IActivityManager proxy: g00.n0(intent, userId)
   ▼
:p0–:p3 (VirtualApp stub processes)
   │  ProxyActivity$P0..P3 โหลด activity จริงของเกม
   ▼
com.miniclip.eightballpool (เกมจริง 56.23.2, base.apk จาก /data/app/~~F1DD…)
```

หลักฐาน: `AndroidManifest.decoded.xml` (shared) · `yu0.java`, `at0.java`, `jv0.java`, `dv0.java`, `g00.java`, `qd0/kd0` (jadx) · `resources_tables/strings.xml` (`engine_service_name` = `:engine`) · `DaemonService.java`

---

## 2. จุดเริ่มต้น (Entry Points)

### 2.1 Application — `com.snake.App`
| ขั้น | โค้ด (จาก jadx) | หลักฐาน |
|---|---|---|
| โหลด native | `static { System.loadLibrary("engine"); }` | `App.java` — `libengine.so` JNI_OnLoad @ `0x1f3fa0` |
| init engine | `attachBaseContext` → `yu0.h().f(ctx, new App.a())` | `yu0.f()`: `s(m())` อ่าน processName → `Main` / `Server` / `ChildAppClient`; Main+Child เรียก `Native.ic(ctx)` |
| start services | `onCreate` → `yu0.h().g()` | `g()`: Main → `at0.d()` ตั้ง Binder managers; `z()` (Child) → `fg.c()`; `B()` (Server) return |
| daemon | `yu0.w()` | Server process → `startForegroundService(DaemonService)` |

### 2.2 Launcher — `com.Entry` (Flutter)
| ขั้น | โค้ด | หลักฐาน |
|---|---|---|
| UI ทั้งหมด Flutter | `dt` extends FlutterActivity; `g0()` สร้าง `kd0` (MethodChannel) ชื่อ `"A"` | `Entry.java` · Blutter `libapp.so` → 672 ไฟล์ dart (Dart 3.5.4) |
| Permission/Analytics | `c0()` POST_NOTIFICATIONS; `a0()` Firebase/FCM token | `Entry.java` |
| Channel handler | `C(id0, dVar)` — `"A"`=Toast, `"B"`=prefs put, `"D"`=prefs get, `"F"`=FCM token, `"G"`=เปิดเกม, `"H"`=install, `"I"`=screen, `"J"`=share | `Entry.java` |

### 2.3 เปิดเกม — MethodChannel `"G"` ⭐
```java
// Entry.C() case "G":
str = list.get(0); parseInt = list.get(1);            // pkg + userId
if (yu0.h().A(str, parseInt) || yu0.h().x(str, parseInt).m)   // installed?
    dVar.c(yu0.h().C(str, parseInt) ? 1 : 0);        // ← เปิดเกม
```
```java
// yu0.C(pkg, userId):
l = u().l(pkg, userId);            // qv0.l(): Intent MAIN+LAUNCHER, setClassName(เกม)
if (l != null) F(l, userId);       // → dv0.C(intent, userId) → g00.n0() [binder → :engine]
```
หลักฐาน: `Entry.java`, `yu0.java`, `qv0.java`, `dv0.java` (jadx) · Blutter strings: `"This game version is not supported…"`, `"The game you have installed is not OFFCIAL version…"` (version check อยู่ฝั่ง Flutter UI)

---

## 3. หลักฐาน Runtime (จากเครื่องจริง — com.snake.zip)

| ไฟล์ | ค่า | ความหมาย |
|---|---|---|
| `root/proc/0/cmdline` | `com.miniclip.eightballpool` | ชื่อ process ลูกที่ engine spawn |
| `root/data/app/com.miniclip.eightballpool/package.conf` | EightBallPoolActivity / EightBallPoolApplication / v56.23.2 (562310023) / พาธจริง `/data/app/~~F1DD…/base.apk` | registry เกมที่ engine mount |
| `root/data/user/0/com.miniclip.eightballpool/a0rjgdfbjd8fhfglkew6/90d8aa15a2de2cb4/arm64-v8a/` | `libgame-BPM-GooglePlay-Gold-Release-Module-3965.so` (67904 B, **เนื้อหาถูกเข้ารหัส**) + `libbuffer_pgl.so` (86 B) + `libpglarmor.so` (220 B) | ไลบรารีเกมที่ engine ดึงออกมา — **สภาพจริง = ไฟล์หลักฐาน ห้ามแตะ** |
| `root/system/*.conf` | uid/user/shared-user | virtual environment confs |
| `shared_prefs/com.snake.xml` | `cip_pub` (ว่าง) | engine pref |

🔒 **ห้ามแตะ:** `comsnake-live/root/data/user/0/com.miniclip.eightballpool/` ทั้งหมด — data จริงของเกมจาก `com.snake.zip` ที่ทำงานอยู่ (หลักฐาน status ทำงานจริง) และ `attachments/uploads/` (ต้นฉบับ zip/apk) — ศูนย์อ่านกลาง

---

## 3.5 🆕 หลักฐาน Dynamic จาก com.ninja.engine.zip — เกม 56.29.1 รันสำเร็จ (เทียบโครง SNAKE)

แหล่ง: `uploads/com.ninja.engine.zip` (สกัดไว้ `workspace/ninja-extract/`) — engine ตระกูลเดียวกัน รัน 8 Ball Pool 56.29.1 บน MIUI สำเร็จ

### ninja = com.app.framework.* (ชื่อไม่ obfuscate — map กลับ SNAKE ได้)
| SNAKE (obfuscated) | ninja (ชื่อจริง) | บทบาท |
|---|---|---|
| `yu0.h()` / jv0 | `BActivityThread` (com.app.framework.app) | fake ActivityThread — handleBindApplication process ลูก |
| (hook Handler) | `HCallbackProxy` (com.app.framework.fake.service) | intercept `handleLaunchActivity` |
| `zh.a()` | `AppInstrumentation` + `BaseInstrumentationDelegate` (com.app.framework.fake.delegate) | Instrumentation delegate — callActivityOnCreate |
| `g00` (AMS stub) | `IBActivityManagerService` (com.app.framework.core.system.am) | Binder ActivityManager (code=3) |
| `x6` (PMS stub) | `IBPackageManagerService` (com.app.framework.core.system.pm) | Binder PackageManager (code=17/5/1599098439) |
| — | `[CORE] server fused app token: 8c1d2e04-3d97-4046-84ea-0e098fba2b5f` | token เชื่อม server↔child |

### Native chain ของ ninja (logcat pid 10446 = `com.ninja.engine:p0`)
```
libZeroGod.so → shadowhook 2.0.1-rc.15 (inline-hook MULTI mode init ok)
→ libnative-lib.so → libninja.so
→ code_cache/engine/lib.so (exec, SELinux granted) + meta {56.29.1 / 33721cc15f2d6964 / token}
→ dlfcn/fake_dlopen: แกะ bionic/libdl.so เอง (dlsym @0x7844d4705c)
→ binder IBPackageManagerService/IBActivityManagerService หา+โหลดเกม
```

### เส้นทางโหลดเกมจริง (timeline จาก logcat)
```
08:00:12.512  nativeloader clns-11: eightballpool base.apk (target_sdk=36, classes12.dex)
08:00:12.560  linker: libloader.so (DT_PREINIT_ARRAY ignored)
08:00:12.573  [CORE]: server fused app token: 8c1d2e04-…
08:00:12.611  KaoriFileUtils.applyKaoriFilePatches(pkg com.miniclip.eightballpool)
08:00:13.023  Unity Ads SDK init (ใน process ลูก)
08:00:14.312  EightBallPoolApplication onCreate
08:00:15.146  EightBallPoolActivity onCreate (HCallbackProxy → AppInstrumentation)
08:00:15.621  EightBallPoolActivity onResume ← เกมรันสำเร็จ
```

### การ mount ข้อมูลเกม
`permitted_path=/data:/mnt/expand:/data/user/0/com.ninja.engine/ninja/data/user/0/com.miniclip.eightballpool` — ตรงโครง `root/` = `ninja/` เหมือน SNAKE

### 🔍 จุดใหม่ที่พบ (แปลกใหม่)
1. **`kaorios`/`KaoriPropsUtils`** = hook framework ฝั่งผู้ใช้ — แทรกที่ `Instrumentation.newApplication` **ก่อนทุกแอพสตาร์ท** (จาก stack: `handleBindApplication → makeApplicationInner → newApplication → KaoriProps(line:1175) → Krtr48kA09tmO323tj8Rgf62eI.Ku5O3sihzbUhwSewE8uI → JSONObject constructor`) — โดย config: `packages:[{name, roots:[{basePath:"/data/data/<pkg>/no_backup", walkChildren:false}], ops:[{type:"search-replace-text", relativePath:"Config/Game.cfg", search:"WaitForVerticalSync=0", replace:"WaitForVerticalSync=1", encoding:"UTF-8", maxReplacements:1}]}]` — ตัวอย่างเจาะจง 3 แพ็กเกจ TFT (teamfighttactics / tw / vn) — **เป็นของระบบตะวันออกเฉียงใต้ ไม่ใช่ของ SNAKE**
2. **`libloader.so`** ของเกม 56.29.1 มี `DT_PREINIT_ARRAY` — SNAKE เก่า (56.23.2) ไม่มีจุดนี้
3. **`xposed-module.conf`** = 8 zero bytes — รองรับโมดูล Xposed แต่ว่าง/ปิด

---

## 3.6 🆕 การสกัดลงลึก com.snake_1.zip — hidden dex evidence + timeline ใช้งานจริง

สกัดไว้ที่ `workspace/snake1-extract/` (สแนปช็อตเครื่อง Xiaomi POCO F1 / beryllium / Android 13 / th_TH)

### สิ่งที่เหมือนเดิม
- `root/` ตรงกับ comsnake-live **100%** (sha256 package.conf = `8ce5af64…` เดียวกัน) — สแนปช็อต 56.23.2 อ้างอิงเดียวกัน

### 🆕 `oat/arm64/Anonymous-DexFile@N.vdex` × 5 — ร่องรอย hidden dex ที่โหลดแบบ in-memory
| ไฟล์ | ขนาด | verifier deps ที่เหลือ |
|---|---|---|
| `@2081314982` | 8,748 B | `Landroid/content/pm/PackageItemInfo;` `Ljava/lang/reflect/Executable;` |
| `@3143459243`, `@967645265` | 156 B | `Ljava/lang/reflect/AccessibleObject;` |
| `@2056690632` | 108 B | — |
| `@4286625232` | 300 B | — |

→ dex จริงถูกโหลดผ่าน **InMemoryDexClassLoader ไม่เขียนลงดิสก์** เหลือแค่ verifier records ที่พิสูจน์ว่า hidden dex ทำงานจริง (22:17) และสัมผัส **reflection API** ตรงกับ `com.snake.helper.MethodUtils` (getDeclaringClass/getDesc แปลง Method→JVM signature สำหรับ `Native.update(obj, method)`)

### Chain ที่ปิดลูปด้วยหลักฐานนี้
```
channel "G" → yu0.C() → binder :engine → ProxyActivity
hidden dex (in-memory) → MethodUtils (Executable/AccessibleObject deps) → Native.update(obj, method) → libengine.so
```

### Timeline การใช้งานจริง (google_app_measurement.db)
```
22:12:34  _f first_open     (com.snake v2.2.2, manual_install)
22:12:34  _s session_start  หน้าจอ Entry (Flutter)
22:14:39  _vs resume
22:14:49  _e/_ab engage_end + backgrounded — ใช้แอพ ~945 วิ (15.75 นาที) ทั้งหมดบน _pc/_sc=Entry
```
→ ยืนยัน: ผู้ใช้ค้างหน้า Entry ตลอด — **เกมไม่เคยเปิดสำเร็จ**ในสแนปช็อตนี้ (ตรงกับสถานะ config เวอร์ชั่น 56.23.2 ไม่ตรงเกมใหม่)

### อื่นๆ
- `com.snake.xml` pref: `cip_pub` ว่าง (ไม่มี license key ฝัง)
- `files/*` = 92 blob เข้ารหัส (Firebase Installations auth)
- datatransport db = 0 events (ไม่มี network call ที่รอส่ง)

---

## 4. หลักฐาน Native (libengine.so) — สภาพ Static

| รายการ | หลักฐาน | สถานะ |
|---|---|---|
| JNI_OnLoad @ `0x1f3fa0` (12280 B) | `01_JNI_OnLoad.c` (Ghidra) | ⚠️ VMP-obfuscated: `CallSupervisor(0)`, jumptable กว่า recover, สตริงเข้ารหัสทั้งหมด → **static ไม่เพียงพอ ต้อง dynamic** |
| RegisterNatives xref | `05_RegisterNatives_xrefs.txt` = `(symbol not found)` | ลงทะเบียน `ic/ac/awl/eio/i/djp/…` แบบ indirect — static หาไม่เจอ |
| init_array 44 ตัว | `03_init_array_decompiles/*` = ทั้งหมด timeout | decompile ไม่ผ่าน (anti-analysis) |
| Java strings | `06_Java_strings.txt` ว่าง | เข้ารหัสล้วน |

**สรุป:** ฝั่ง Java/Flutter/manifest/runtime = หลักฐานเชื่อมโยงครบสมบูรณ์ แต่ **ฝั่ง native ยังเชื่อมไม่ติด** — `Native.ic()` → โค้ดจริงใน libengine.so ต้องจับขณะรัน (Frida hook `RegisterNatives` + `Native.ic` + Binder transact)

---

## 5. จุดที่ต้องต่อเพื่อให้เส้นทางสมบูรณ์ (ต้อง dynamic)

| ลำดับ | จุด | เครื่องมือ |
|---|---|---|
| 1 | `System.loadLibrary("engine")` → `JNI_OnLoad` → RegisterNatives mapping | Frida: `art::JNI::RegisterNatives` hook |
| 2 | `Native.ic(ctx)` — ทำอะไรต่อ (เปิดไฟล์? binder? thread?) | Frida: hook native method + `openat`/`connect` |
| 3 | Binder Main→`:engine`: `g00.n0()` → startActivity จริง | Frida: `android.os.BinderProxy.transact` / `k1.a()` |
| 4 | `:engine` → ProxyActivity → ClassLoader ของเกม | hook `InMemoryDexClassLoader`/`LoadedApk` |
| 5 | MethodChannel `"G"` payload จริงจาก Dart | hook `MethodChannel.invokeMethod` หรือ `Native.djp` |

---

## 6. ไฟล์อ้างอิงหลัก (ภายใน workspace)

- `snake_apk_extract/jadx_out/sources/com/snake/App.java` — Application entry
- `snake_apk_extract/jadx_out/sources/com/Entry.java` — Launcher + channel G
- `snake_apk_extract/jadx_out/sources/com/snake/helper/Native.java` — JNI bridge
- `snake_apk_extract/jadx_out/sources/androidx/appcompat/view/menu/yu0.java` — role/process/launcher chain
- `snake_apk_extract/jadx_out/sources/androidx/appcompat/view/menu/{qv0,dv0,g00,at0,jv0}.java` — Intent build + Binder AMS proxy
- `comsnake-live/root/proc/0/cmdline` · `root/data/app/.../package.conf` — runtime evidence
- `binary-analysis/` — repo CI (Ghidra/Blutter) สำหรับต่อยอด (remote: github.com/engine-dev01/binary-analysis)
- ส่วนกลาง (อ่านอย่างเดียว): `/var/minis/shared/analysis/ghidra-extractjni-2026-09-12/`
