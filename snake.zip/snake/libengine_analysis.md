# libengine.so — Deep Analysis (Snake Engine native core)

หลักฐานทั้งหมดจากการ decode/disassemble ไฟล์จริง — ไม่มีการเดา
ไฟล์: `libengine.so` · MD5 `2ae5d2b628942e13fce7a48728ebee25` · 8,544,568 B

---

## 1. ชนิดไฟล์ (verified)
- ELF64 · AArch64 · DYN (shared object) · SONAME `libengine.so`
- compiler = Android clang 14.0.6 (r450784d) · linker = LLD 14.0.6
- NEEDED: `libm.so`, `libdl.so`, `libc.so`
- โหลดผ่าน `System.loadLibrary("engine")` จาก `com.snake.App.<clinit>` (ยืนยันข้าม classes.dex)

## 2. โครง section (หลักฐาน readelf)
| section | vaddr | หมายเหตุ |
|---|---|---|
| .text | 0x52150 (0x7ccd5c) | code หลัก |
| **.mytext** | 0x81eeac (0xf4) | section แยก = hallmark ของ obfuscator |
| .plt | 0x81efa0 | |
| .data.rel.ro | 0x820830 | |
| .init_array | 0x825c78 | ctor (จาก rela.dyn: 0x52378 ฯลฯ) |
| .got.plt | 0x8263f8 | |

- Export **เดียว: `JNI_OnLoad` @ 0xf3fa0 (12,388 B)** — ไม่มี `Java_*` symbol เลย
- 2,343 R_AARCH64_RELATIVE reloc · 135 imported libc functions

## 3. ★ JNI_OnLoad = Runtime Code Generator (self-modifying, anti-RE) ★
disassemble เต็ม 12KB — นี่ไม่ใช่ JNI registration ปกติ แต่เป็น **trampoline builder ที่สร้างโค้ดตอนรัน**:

```asm
loop 7 รอบ (cmp x22,#7 @0xf40b4)
  0xf4018: svc #0  w8=0xde(222)=mmap  prot=7(RWX)  flags=0x22(PRIVATE|ANON)   ; จอง RWX ดิบ
  0xf406c: bl 0x81f120 (rand@plt)                                             ; สุ่ม
  0xf4070: and w8,w0,#0x3ffffff / #0xffff ; orr กับ template 0x14000000(B)/0x2be00000
  0xf4078: str w8,[x21,x27]                                                   ; เขียน instr ลง RWX
  0xf40ac: bl 0x81ad58 = __clear_cache (dc cvau / ic ivau / dsb ish / isb)    ; flush i-cache
  0xf40e0: blr x8                                                             ; รันโค้ดที่เพิ่งสร้าง
```

สถิติที่นับได้ใน JNI_OnLoad (disasm ยืนยัน):
- **svc รวม 40 ครั้ง** (w8=0xde/mmap 26 ครั้ง + brk/อื่น)
- **blr (รัน generated stub) 20 ครั้ง**
- **__clear_cache (0x81ad58) 10 ครั้ง**
- syscall แบบ **raw `svc #0`** (ไม่ผ่าน libc) → เลี่ยง libc hook / seccomp detection

`0x81ad58` disasm = อ่าน `ctr_el0` + `dc cvau` + `ic ivau` + `dsb ish` + `isb` = **`__clear_cache` มาตรฐาน** → ยืนยัน self-modifying code

**ผลกระทบ:** `RegisterNatives` ถูก dispatch ผ่านโค้ด RWX ที่ generate ตอน runtime → **หา static ไม่ได้ตามการออกแบบ** (native method `ic/chl/djp/update` bind ตอนรันเท่านั้น) — นี่คือ anti-reversing เชิงโครงสร้าง ไม่ใช่การเข้ารหัส payload

## 4. .mytext (0x81eeac, 0xf4 B) — ไม่ได้เข้ารหัส
- entropy 5.26 (โค้ดปกติ) — disasm ได้ 2 thunk เล็ก
- ตั้ง flag JNIEnv ผ่าน `[x0, +0x828d98]` (orr #1 / #0x10000000 / and #~0x10) แล้ว `bl 0xb01c4`/`0xb134c`
- = JNIEnv exception/flag helper (ไม่ใช่ code ที่ซ่อน)

## 5. String obfuscation — ★ ถอดสำเร็จ ★
- scheme: `plaintext[off] = ciphertext[off] XOR ((off + 0xA4) & 0xFF)` — **keystream เชิงเส้นตาม file offset**
- verify: 0x2e558 → `snakeengine.com/oauth/google` ✅
- ถอดได้ ~2,480 string → ไฟล์ [libengine_strings.txt](minis://workspace/libengine_strings.txt)

## 6. Capabilities ที่ยืนยันได้ (จาก imports + decoded strings)

### 6.1 Custom ELF loader (โหลด .so เอง เลี่ยง system linker)
- `__dl__ZN9ElfReader4LoadEP20address_space_params` (ElfReader::Load) @ 0x2c950
- `[soListAddress] %p %p` @ 0x2c750 · `apply_symbol_overrides` @ 0x2b54f
- imports: `mmap`, `mprotect`, `munmap`, `dlsym`, `dladdr`, `dl_iterate_phdr`
- **นี่คือจุดที่ปลด+โหลด PGL payload** (libpglarmor/libbuffer_pgl/libgame-Module-3965)

### 6.2 Runtime DEX/reflection loader
- `InMemoryDexClassLoader` sig `(Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V` @ 0x2d450 → โหลด DEX จาก memory
- `com/snake/helper/Native` @ 0x2cf50 · `MethodUtils` · `(Ljava/lang/reflect/Method;)Ljava/lang/String;` → reflection bridge (คู่กับ `Native.update`)

### 6.3 Anti-detection (root / frida / emulator / tamper)
- root: `/system/bin/failsafe/su` @ 0x2bd50, `bin/su`, `xbin/su`, `Superuser.apk`
- frida: `GADGET` @ 0x2ba30
- device fingerprint: `ro.product.device` @ 0x2aa50, `__system_property_get`, `__system_find_prop_123` @ 0x30d50
- imports รองรับ: `getauxval`, `prctl`, `syscall`, `process_vm_readv`, `readlink`

### 6.4 Filesystem redirect / hide (ซ่อนไฟล์จากการตรวจ)
- hook `libcore/io/Linux` @ 0x2dc50 (readlink/access/unlink/stat)
- hook `java/io/UnixFileSystem` @ 0x2e150 · `setReadOnly0` @ 0x2e350 · `REALPATH` @ 0x2b386
- working dir: `/data/data/com.snake/files/` @ 0x2bc50
- คู่กับ `com.snake.helper.Native.il(File)/il(String)` = path redirect

### 6.5 OAuth / auth
- `https://snakeengine.com/oauth/google` @ 0x2e550
- Google OAuth client-id `...nip3p.apps.googleusercontent.com`
- class `.googleplaygames.Authentication`

### 6.6 Crash reporting (xcrash framework)
- import `_ZN16xcrash_oneheader6detail5pipe2EPii`
- `{crash}` @ 0x2d030 · `[CRASH] log data size %d %s` @ 0x2d150 · `[C] backtrace data size %d` @ 0x2ef50
- signal: `SIGFPE`/`FPE_INTDIV` — ติดตั้ง `sigaction`/`sigaltstack`

## 7. Imports สำคัญ (135 ตัว — highlight)
`mmap` `mprotect` `munmap` `dlsym` `dladdr` `dl_iterate_phdr` `process_vm_readv` `prctl` `syscall` `getauxval` `__system_property_get` `pthread_create` `readlink` `stat` `getaddrinfo` `sigaction` `sigaltstack` `android_set_abort_message`

---

## ⚠️ เพดาน static (ระบุตามหลักฐาน ไม่เดา)
1. **JNINativeMethod table หา static ไม่เจอ** — scan .data/.data.rel.ro ได้ 1 false hit; RegisterNatives ถูกเรียกผ่าน RWX-generated code ใน JNI_OnLoad → mapping Java↔native ต้อง trace ตอน runtime
2. **body ของ native fn (chl/djp/ic/update)** — bind runtime ผ่าน generated stub → ยังไม่ resolve ถึง address ด้วย static
3. keystream หลัก 0xA4 ตรงเป๊ะ region หลัก; บาง block มี case-flip เล็กน้อย (`cONTENTrESOLVER`) → ความหมายชัดแล้ว ถ้าต้องการ byte-perfect ต้องหา per-block key

